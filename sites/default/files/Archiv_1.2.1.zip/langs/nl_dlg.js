/* $Id: nl_dlg.js,v 1.4 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('nl.Archiv_dlg',{
	Ftitle : "Archiv - File browser",
	FtreeTitle: "Mappen",
	ContentOf: "Inhoud van",
	RemoveDirectory: "Map verwijderen",
	UploadButton : "Upload een of meerdere bestanden",
	UploadQueue: "Bestanden in wachtrij",
	AddDirectory: "Map toevoegen",
	BarClose: "Sluiten",
	BarOpen: "Openen"
});