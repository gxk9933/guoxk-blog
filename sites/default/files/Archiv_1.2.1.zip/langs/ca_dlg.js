/* $Id: ca_dlg.js,v 1.3 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('ca.Archiv_dlg',{
	Ftitle : "Archiv - Navegador d'arxius",
	FtreeTitle: "Directoris",
	ContentOf: "Contingut de",
	RemoveDirectory: "Esborrar directori",
	UploadButton : "Afegeix un o més arxius",
	UploadQueue: "Arxius en cua",
	AddDirectory: "Afegir carpeta",
	BarClose: "Tanca",
	BarOpen: "Obrir"	
});