<?php
/**
 * Archiv Catalan language file
 * 
 * @id: $Id: ca.php,v 1.3 2009/10/27 20:15:55 wvankuipers Exp $
 * @version 1.0
 * @author designer - ALEXANDRE ENRICH  www.designer.cat
 * @copyright 2008-2009 pwnd.nl
 * @license LGPL
 * @see http://archiv.pwnd.nl
 *
 */

$lang['ErrorCreatingDirectory'] 		= "Error al crear la carpeta!";
$lang['ErrorDirectoryAlreadyExists'] 	= "La carpeta ja existeix!!";
$lang['ErrorFileAlreadyExists'] 		= "No és pot esborrar la vista prèvia de la imatge!"; 
$lang['ErrorUnableToReadPath'] 		= "No és pot llegir el camé (path)";
$lang['ErrorInvalidUpload'] 		= "Pujada inv�lida";
$lang['ErrorWrongMimeType'] 		= "Pujada inv�lida, tipus mime incorrecte!";
$lang['ErrorRemoveingThumb'] 		= "No és pot esborrar el thumb de la imatge!";
$lang['ErrorRemoveingFile'] 		= "No és pot esborrar l'arxiu!";
$lang['ErrorNoFile'] 				= "No és pot esborrar l'arxiu, no és un arxiu";
$lang['ErrorRemovingDirectory'] 	= "No és pot esborrar el directori!";
$lang['ErrorNoDirectory'] 			= "No és pot esborrar el directori, no és un directori";
$lang['ErrorNoAccess'] 				= "Error accés restringit!";
?>