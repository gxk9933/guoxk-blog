/* $Id: es_dlg.js,v 1.3 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('en.Archiv_dlg',{
	Ftitle : "Archiv - Administrador de archivos",
	FtreeTitle: "Carpetas",
	ContentOf: "Contenido de",
	RemoveDirectory: "Eliminar carpeta",
	UploadButton : "Subir uno o mas archivos",
	UploadQueue: "Archivos en cola",
	AddDirectory: "Agregar carpeta",
	BarClose: "Cerrar",
	BarOpen: "Abrir"
});