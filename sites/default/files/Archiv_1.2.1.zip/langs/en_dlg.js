/* $Id: en_dlg.js,v 1.4 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('en.Archiv_dlg',{
	Ftitle : "Archiv - File browser",
	FtreeTitle: "Directories",
	ContentOf: "Content of",
	RemoveDirectory: "Remove directory",
	UploadButton : "Upload one or more files",
	UploadQueue: "Files in Queue",
	AddDirectory: "Add directory",
	BarClose: "Close",
	BarOpen: "Open"
});