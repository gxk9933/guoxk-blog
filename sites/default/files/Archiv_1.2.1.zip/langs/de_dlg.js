/* $Id: de_dlg.js,v 1.4 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('de.Archiv_dlg',{
	Ftitle : "Archiv - Dateibrowser",
	FtreeTitle: "Verzeichnisse",
	ContentOf: "Inhalt von",
	RemoveDirectory: "Verzeichnis l&ouml;schen",
	UploadButton : "Datei(en) hochladen",
	UploadQueue: "Dateien in Warteschlange",
	AddDirectory: "Ordner hinzuf&uuml;gen",
	BarClose: "Schlie&szlig;en",
	BarOpen: "&Ouml;ffnen"
});
