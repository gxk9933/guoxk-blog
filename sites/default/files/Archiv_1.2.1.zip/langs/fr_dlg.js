/* $Id: fr_dlg.js,v 1.3 2009/10/27 20:15:55 wvankuipers Exp $ */
tinyMCE.addI18n('fr.Archiv_dlg',{
	Ftitle : "Archiv - Gestionnaire de fichier",
	FtreeTitle: "Dossiers",
	ContentOf: "Contenu de",
	RemoveDirectory: "Supprimmer un dossier",
	UploadButton : "Téléverser un ou plusieurs fichiers",
	UploadQueue: "Fichiers en file d\'attente",
	AddDirectory: "Ajouter un dossier",
	BarClose: "Fermer",
	BarOpen: "Ouvrir"
});